import { IDict } from "../../interfaces.js";
export declare const COINS_FRAXTAL_TESTNET: IDict<string>;
export declare const DECIMALS_FRAXTAL_TESTNET: IDict<number>;
export declare const cTokensFraxtalTestnet: never[];
export declare const yTokensFraxtalTestnet: never[];
export declare const ycTokensFraxtalTestnet: never[];
export declare const aTokensFraxtalTestnet: never[];
