import type { IDict, IRoutePoolData, IRouteStep } from "./interfaces";
export type IRouterWorkerInput = {
    inputCoinAddress: string;
    outputCoinAddress: string;
    routerGraph: IDict<IDict<IRouteStep[]>>;
    poolData: IDict<IRoutePoolData>;
};
export declare function routeFinderWorker(): (({ inputCoinAddress, outputCoinAddress, routerGraph, poolData }: IRouterWorkerInput) => IRouteStep[][]) | undefined;
export declare const routeFinderWorkerCode: string;
