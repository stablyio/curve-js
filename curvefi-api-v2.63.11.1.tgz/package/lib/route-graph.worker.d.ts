import type { IChainId, IDict, IPoolData, IRouteStep } from "./interfaces";
import type { curve } from "./curve";
export type IRouteGraphInput = {
    constants: typeof curve['constants'];
    chainId: IChainId;
    allPools: [string, IPoolData][];
    amplificationCoefficientDict: IDict<number>;
    poolTvlDict: IDict<number>;
};
export declare function routeGraphWorker(): (({ constants, chainId, allPools, amplificationCoefficientDict, poolTvlDict }: IRouteGraphInput) => IDict<IDict<IRouteStep[]>>) | undefined;
export declare const routeGraphWorkerCode: string;
